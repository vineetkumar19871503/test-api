const Nexmo = require('nexmo')

const nexmo = new Nexmo({
    apiKey: '6f8deb2f',
    apiSecret: '0dc5214ff99d8893'
});

// const nexmo = new Nexmo({
//     apiKey: '6f8deb2f',
//     apiSecret: '0dc5214ff99d8893'
// });

const from = 'NEXMO';
const to = 919057506754;
const text = 'Hii this is vineet kumar. Do not reply to this message.';

nexmo.message.sendSms(from, to, text, function (res, b) {
    console.log(res);
    console.log(b);
});