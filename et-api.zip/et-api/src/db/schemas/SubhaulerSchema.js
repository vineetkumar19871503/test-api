const mongoose = require('mongoose'),
    Schema = mongoose.Schema;

//defining schemas
const schemas = {
    subhaulers: new Schema({
        name: String,
        username:String,
        password:String
    })
};

//creating models for collections
const models = {
    subhaulerModel: mongoose.model('subhaulers', schemas.subhaulers),
}
module.exports = {
    schemas,
    models
};