const mongoose = require('mongoose'),
    Schema = mongoose.Schema;

//defining schemas
const schemas = {
    trucker_locations: new Schema({
        trucker_id: { type: Schema.Types.ObjectId, required: true },
        tag_id: { type: String, default: null },
        lat: Number,
        lng: Number,
        created_date: Date
    })
};

//creating models for collections
const models = {
    truckerLocationModel: mongoose.model('trucker_locations', schemas.trucker_locations)
}

module.exports = {
    schemas,
    models
};