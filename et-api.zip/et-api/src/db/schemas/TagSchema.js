const mongoose = require('mongoose'),
    Schema = mongoose.Schema;

//defining schemas
const schemas = {
        tags: new Schema({
            subjob_id:String,
            account_no: String,
            customer_name:String,
            admin_deduct_time: {
                hour: String,
                minute: String,
            },
            admin_net_time: String,
            admin_start_time: {
                hour: String,
                minute: String,
            },
            admin_stop_time: {
                hour: String,
                minute: String,
            },
            chp_finish_time: {
                hour: String,
                minute: String,
            },
            chp_start_time: {
                hour: String,
                minute: String,
            },
            chp_total_time: String,
            destination: {
                address: String,
                lat: String,
                lng: String
            },
            document: Array,
            driver_name:String,
            job_id:String,
            loading_details: [
                {
                    net_stand_by: String,
                    time_arrival: {
                        hour: String,
                        minute: String,
                    },
                    time_leave: {
                        hour: String,
                        minute: String,
                    },
                }
            ],
            material:String,
            material_charged_to:String,
            material_details: [
                {
                    scale_tag_no: String,
                    weight: String,
                    yards: String,
                }
            ],
            origin: {
                address: String,
                lat: String,
                lng: String
            },
            prime_carrier:String,
            received_by:String,
            sign_out_time:{
                hour: String,
                minute: String,
            },
            tag_id:String,
            trailer:String,
            truck:String,
            truck_types:String,
            un_loading_time: [
                {
                    net_stand_by: String,
                    time_arrival: {
                        hour: String,
                        minute: String,
                    },
                    time_leave: {
                        hour: String,
                        minute: String,
                    },
                }
            ],
        })
        
    };

//creating models for collections
const models = {
    tagModel: mongoose.model('tags', schemas.tags),
}

module.exports = {
    schemas,
    models
};