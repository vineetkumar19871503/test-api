const mongoose = require('mongoose'),
    Schema = mongoose.Schema;

//defining schemas
const schemas = {
    customers: new Schema({
        cust_id: String,
        org_name: String,
        org_address: String,
        org_city: String,
        org_state: String,
        org_country: String,
        org_pincode: { type: Number, maxlength: 6 },
        org_mobile: String,
        org_phone: String,
        cus_name: String,
        cust_role: String,
        cust_dob: { type: Date, default: Date.now },
        cust_email: String,
        cust_contact: String,
        cust_nationality: String,
        cust_address: String,
        cust_city: String,
        cust_state: String,
        cust_country: String,
        cust_pincode: { type: Number, maxlength: 6 },
        contact_details: [
                {
                    name: String,
                    phone: String,
                    email: String,
                    description: String,
                }
            ],
        cust_logs :[{
            'uid': { type: Schema.Types.ObjectId, required: true },
            'name': String,
            'notes': String,
            'date': {type: Date,default: Date.now }
        }],
        cust_notes :String
    }),
    customers_logs: new Schema({
         c_id:String,
         name: String,
         notes: String,
        date: { type: Date, default: Date.now  },
    })
};

//creating models for collections
const models = {
    customersModel: mongoose.model('customers', schemas.customers),
    customerLogModel: mongoose.model('customers_logs', schemas.customers_logs)
}
module.exports = {
    schemas,
    models
};