const mongoose = require('mongoose'),
    Schema = mongoose.Schema;
    const { getToday } = require('../../globals/methods');

//defining schemas
const schemas = {
    trucker_signing_offs: new Schema({
        tag_id: { type: String, default: null },
        job_id: { type: Schema.Types.ObjectId, required: true },
        trucker_signature: { type: String, default: null },
        trucker_comments: { type: String, default: null },
        customer_signature : { type: String, default: null },
        customer_feedback: { type: String, default: null },
        material_charges_to: { type: String, default: null },
        deducted_hrs: { type: String, default: null },
        created_date: { type: Date, default: getToday() }
    })
};

//creating models for collections
const models = {
    truckerSigningOffModel: mongoose.model('trucker_signing_offs', schemas.trucker_signing_offs)
}

module.exports = {
    schemas,
    models
};