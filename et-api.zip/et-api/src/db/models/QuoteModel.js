const quoteModel = require('../../db/schemas/QuoteSchema').models.quoteModel,
    customerModel = require('../../db/schemas/CustomerSchema').models.customersModel;
module.exports = {
    getQuotes: function (conditions = {}, fields = {}, order = { '_id': -1 }) {
        return new Promise(function (resolve, reject) {
            var query = [
                {
                    $lookup: {
                        from: 'customers',
                        localField: 'c_id',
                        foreignField: '_id',
                        as: 'customer'
                    }
                },
                { $unwind: '$customer' },
                { $match: conditions }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }
            quoteModel.aggregate(query)
                .exec(function (err, quotes) {
                    err ? reject(err) : resolve(quotes);
                });
        });
    },

    getAllQuotesByCustomerId: function (conditions = {}, fields = {}, order = { '_id': 'descending' }) {
        return new Promise(function (resolve, reject) {
            var query = quoteModel.find(conditions);
            if (Object.keys(fields).length) {
                query.select(fields);
            }
            query.sort(order).exec(function (err, quotesWithStatus) {
                err ? reject(err) : resolve(quotesWithStatus);
            });
        });
    },
    save: function (data) {
        return new Promise(function (resolve, reject) {
            quoteModel.insertMany(data, function (err, quote) {
                err ? reject(err) : resolve(quote);
            });
        });
    },
    // updates job or sub job. conditions will be matched and type will be either 'j' (job) or 's' (subjob)
    update: function (conditions, data, upsert = false) {
        return new Promise(function (resolve, reject) {
            quoteModel.update(conditions,
                { $set: data },
                { upsert },
                function (err, res) {
                    err ? reject(err) : resolve(res);
                })
        });
    },
    getQuotesCountByCustomer: function (conditions = {}, fields = {}, order = { 'q_id': -1 }) {
        return new Promise(function (resolve, reject) {
            var query = [
                {
                    $lookup: {
                        from: 'quotes',
                        localField: '_id',
                        foreignField: 'c_id',
                        as: 'quote'
                    }
                },
                { $unwind: '$quote' },
                {
                    $match: conditions
                },
                {
                    $group: {
                        _id: '$_id',
                        'q_id': { $first: '$quote._id' },
                        'quotes_count': { $sum: 1 },
                        'c_id': { $first: '$_id' },
                        'customer_id': { $first: '$customer_id' },
                        'cust_name': { $first: '$cust_name' },
                        'cust_role': { $first: '$cust_role' },
                        'org_name': { $first: '$org_name' }
                    }
                }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }
            customerModel.aggregate(query)
                .exec(function (err, quotesCount) {
                    err ? resolve(err) : resolve(quotesCount);
                });
        });

    },
    getJobsCountByCustomer: function (conditions = {}, fields = {}, order = {}) {
        return new Promise(function (resolve, reject) {
            var query = [
                {
                    $lookup: {
                        from: 'quotes',
                        localField: '_id',
                        foreignField: 'c_id',
                        as: 'quote'
                    }
                },
                { $unwind: '$quote' },
                {
                    $match: conditions
                },
                {
                    $group: {
                        _id: '$_id',
                        'quotes_count': { $sum: 1 },
                        'c_id': { $first: '$_id' },
                        'customer_id': { $first: '$customer_id' },
                        'cust_name': { $first: '$cust_name' },
                        'cust_role': { $first: '$cust_role' },
                        'org_name': { $first: '$org_name' }
                    }
                }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }
            customerModel.aggregate(query)
                .exec(function (err, jobsCount) {
                    err ? resolve(err) : resolve(jobsCount);
                });
        });
    }
}

