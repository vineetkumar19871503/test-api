const assignedJobModel = require('../../db/schemas/AssignedJobSchema').models.assignedJobModel,
    { addZeroes } = require('../components/counter'),
    driverModel = require('../../db/models/DriverModel'),
    dispatchModel = require('../../db/schemas/DispatchSchema').models.dispatchModel,
    objectId = require('mongoose').Types.ObjectId,
    subJobModel = require('../../db/schemas/JobSchema').models.subJobModel;
module.exports = {
    getAssignedJobs: function (conditions = {}, fields = {}, order = {}) {
        const self = this;
        return new Promise(function (resolve, reject) {
            var query = [
                {
                    $lookup: {
                        from: 'sub_jobs',
                        localField: 'job_id',
                        foreignField: '_id',
                        as: 'job'
                    }
                },
                {
                    $lookup: {
                        from: 'truckers',
                        localField: 'drivers.driver_id',
                        foreignField: '_id',
                        as: '$driver'
                    }
                },

                { $unwind: '$driver' },
                { $unwind: '$job' },
                {
                    $match: conditions
                }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }
            assignedJobModel.aggregate(query)
                .exec(function (err, data) {
                    err ? reject(err) : resolve(data);
                });
        });

    },
    getAssignedDataByDispatchId: function (dispatchId) {
        return new Promise(function (resolve, reject) {
            assignedJobModel.find({ 'dispatch_id': dispatchId }, function (err, data) {
                err ? reject(err) : resolve(data);
            })
        });
    },
    delete: function (conditions) {
        return new Promise(function (resolve, reject) {
            assignedJobModel.remove(conditions, function (err) {
                err ? reject(err) : resolve();
            });
        });
    },
    save: function (data) {
        return new Promise(function (resolve, reject) {
            assignedJobModel.insertMany(data, function (err, assignedJob) {
                err ? reject(err) : resolve(assignedJob);
            });
        });
    },
    update: function (conditions = {}, data = {}, upsert = true) {
        return new Promise(function (resolve, reject) {
            assignedJobModel.update(conditions,
                { $set: data },
                { upsert },
                function (err, numAffected, raw) {
                    err ? reject(err) : resolve(raw);
                });
        });
    },

    getTruckersByTagid: function (conditions = {}, fields = {}, order = {}) {
        return new Promise(function (resolve, reject) {
            var query = [
                {
                    $lookup: {
                        from: 'truckers',
                        localField: 'drivers.driver_id',
                        foreignField: '_id',
                        as: 'driver'
                    }
                },
                { $unwind: '$driver' },
                {
                    $lookup: {
                        from: 'dispatches',
                        localField: 'dispatch_id',
                        foreignField: '_id',
                        as: 'dispatch'
                    }
                },
                { $unwind: '$dispatch' },
                {
                    $lookup: {
                        from: 'sub_jobs',
                        localField: 'dispatch.job_id',
                        foreignField: '_id',
                        as: 'job'
                    }
                },
                { $unwind: '$job' },
                {
                    $lookup: {
                        from: 'customers',
                        localField: 'c_id',
                        foreignField: 'job.c_id',
                        as: 'customer'
                    }
                },
                { $unwind: '$customer' },

                {
                    $match: conditions
                }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }
            assignedJobModel.aggregate(query)
                .exec(function (err, data) {
                    err ? reject(err) : resolve(data);
                });
        });
    },
    getTruckersByTagidNew: function (conditions = {}, fields = {}, order = {}) {
        return new Promise(function (resolve, reject) {
            var query = [
                             {
                    $lookup: {
                        from: 'truckers',
                        localField: 'drivers.driver_id',
                        foreignField: '_id',
                        as: 'driver'
                    }
                },
                { $unwind: '$driver' },
                { $unwind: '$drivers' },
                {
                    $lookup: {
                        from: 'dispatches',
                        localField: 'dispatch_id',
                        foreignField: '_id',
                        as: 'dispatch'
                    }
                },
                { $unwind: '$dispatch' },
                {
                    $lookup: {
                        from: 'sub_jobs',
                        localField: 'dispatch.job_id',
                        foreignField: '_id',
                        as: 'job'
                    }
                },
                { $unwind: '$job' },
                {
                    $lookup: {
                        from: 'customers',
                        localField: 'job.c_id',
                        foreignField: '_id',
                        as: 'customer'
                    }
                },
                { $unwind: '$customer' },
                {
                    $match: conditions
                },
                {
                    $group: {
                        _id: '$_id',
                        driver: { $addToSet: '$drivers' },
                        driver_detail: { $addToSet: '$driver' },
                        dispatch: { $first: '$dispatch' },
                        job: { $first: '$job' },
                        customer: { $first: '$customer' }
                    }
                }
                
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }
            assignedJobModel.aggregate(query)
                .exec(function (err, data) {
                    err ? reject(err) : resolve(data);
                });
        });
    },
    getAllTagidGeneratedSubJob: function (conditions = {}, fields = {}, order = {}) {
        return new Promise(function (resolve, reject) {
            var query = [
                {
                    $lookup: {
                        from: 'dispatches',
                        localField: 'dispatch_id',
                        foreignField: '_id',
                        as: 'dispatch'
                    }
                },
                { $unwind: '$dispatch' },
                {
                    $lookup: {
                        from: 'sub_jobs',
                        localField: 'dispatch.job_id',
                        foreignField: '_id',
                        as: 'job'
                    }
                },
                { $unwind: '$job' },
                {
                    $lookup: {
                        from: 'customers',
                        localField: 'job.c_id',
                        foreignField: '_id',
                        as: 'customer'
                    }
                },
                { $unwind: '$customer' },
                {
                    $match: conditions
                },
                {
                    $group: {
                        _id: '$_id',
                        'customer_id': { $first: '$customer.customer_id' },
                        'cust_name': { $first: '$customer.cust_name' },
                        'jobid': { $first: '$job.pjob_id' },
                        'subjobid': { $first: '$job.subjob_id' },
                        'job_name': { $first: '$job.job_name' },
                        'tag_id': { $first: '$drivers.tag_id' },
                        'subjobobjid': { $first: '$job._id' },
                        'c_id': { $first: '$customer._id' },
                    }
                }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }

            assignedJobModel.aggregate(query)
                .exec(function (err, data) {
                    err ? reject(err) : resolve(data);
                });
        });
    },
    getTagidGeneratedBySingleSubJob: function (conditions = {}, fields = {}, order = {}) {
        return new Promise(function (resolve, reject) {
            var query = [
                {
                    $lookup: {
                        from: 'assigned_jobs',
                        localField: '_id',
                        foreignField: 'dispatch_id',
                        as: 'assign'
                    }
                },
                { $unwind: '$assign' },
                {
                    $lookup: {
                        from: 'sub_jobs',
                        localField: 'job_id',
                        foreignField: '_id',
                        as: 'job'
                    }
                },

                { $unwind: '$job' },
                {
                    $lookup: {
                        from: 'customers',
                        localField: 'job.c_id',
                        foreignField: '_id',
                        as: 'customer'
                    }
                },

                { $unwind: '$customer' },

                {
                    $match: conditions
                },
                {
                    $group: {
                        _id: '$_id',
                        'tag_id': { $first: '$assign.drivers.tag_id' },
                        'jobsite': { $first: '$job.origin.address' },
                        'querysite': { $first: '$job.destination.address' },
                        'subjobid': { $first: '$job._id' },
                        'job_name': { $first: '$job.job_name' },
                        'tag_id_status': { $first: '$assign.drivers.tag_id_status' },
                        'customer_name': { $first: '$customer.org_name' },
                        'jobid': { $first: '$job.pjob_id' },
                        'subjobid': { $first: '$job.subjob_id' },
                        'customer_id': { $first: '$customer.customer_id' },
                        'c_id': { $first: '$customer._id' },
                    }
                }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }
            dispatchModel.aggregate(query)
                .exec(function (err, data) {
                    err ? reject(err) : resolve(data);
                });
        });
    },
    // get the assign and driver data by message id
    approveDriversJob: function (conditions = {}, fields = {}, order = {}) {
        const self = this;
        return new Promise(function (resolve, reject) {
            var query = [
                { $unwind: '$drivers' },
                {
                    $lookup: {
                        from: 'dispatches',
                        localField: 'dispatch_id',
                        foreignField: '_id',
                        as: 'dispatch'
                    }
                },
                { $unwind: '$dispatch' },
                {
                    $lookup: {
                        from: 'sub_jobs',
                        localField: 'dispatch.job_id',
                        foreignField: '_id',
                        as: 'job'
                    }
                },
                { $unwind: '$job' },
                {
                    $match: conditions
                },
                {
                    $group: {
                        _id: '$_id',
                        driver: { $first: '$drivers' },
                        dispatch: { $first: '$dispatch' },
                        job: { $first: '$job' }
                    }
                }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }
            assignedJobModel.aggregate(query)
                .exec(function (err, data) {
                    if (err) {
                        reject(err);
                    } else {
                        if (data.length) {
                            data = data[0];
                            let _dd = data.dispatch.date,
                                _d = _dd.getDate().toString(),
                                _m = (_dd.getMonth() + 1).toString(),
                                _y = _dd.getFullYear().toString();
                            _d = _d.length == 1 ? '0' + _d : _d;
                            _m = _m.length == 1 ? '0' + _m : _m;
                            const assignJobId = data._id,
                                custId = data.job.customer_id,
                                driverId = data.driver.driver_id,
                                jobId = data.job.pjob_id;
                            _dd = _m + _d + _y;
                            // get all the tag ids for today and find the next tag id to provide
                            self.getAllTagIdsByDate(new Date(), { 'drivers.tag_id': 1 }, 'desc')
                                .then(function (tagIds) {
                                    let nextTagId = 1;
                                    if (tagIds.length) {
                                        nextTagId = parseInt(tagIds[0].slice(-4)) + 1
                                    }
                                    nextTagId = _dd + custId + jobId + addZeroes('tag_id', nextTagId);
                                    // assign the next tag id to driver
                                    self._updateDriversConfirmation(assignJobId, conditions['drivers.message_id'], nextTagId)
                                        .then(function () {
                                            // update job_approved flag in truckers collection
                                            driverModel.update({ '_id': objectId(driverId) }, { 'job_approved': true });
                                            resolve();
                                        })
                                        .catch(function (err) {
                                            reject(err);
                                        });
                                })
                                .catch(function (err) {
                                    reject(err);
                                });
                        } else {
                            resolve(data);
                        }
                    }
                });
        });
    },
    // get all generated tag ids for a given date
    getAllTagIdsByDate: function (date = new Date(), fields = {}, order = 'asc') {
        return new Promise(function (resolve, reject) {
            const dt = new Date(date),
                nextDate = new Date(date);
            nextDate.setDate(dt.getDate() + 1);
            dt.setHours(0, 0, 0, 0);
            nextDate.setHours(0, 0, 0, 0);
            dt.toISOString();
            nextDate.toISOString();
            const conditions = {
                'start_time': {
                    '$gte': dt,
                    '$lt': nextDate
                },
                'drivers.tag_id': { $ne: null }
            };
            var query = [
                { $unwind: '$drivers' },
                {
                    $match: conditions
                },
                {
                    $group: {
                        _id: '$_id',
                        drivers: { $push: '$drivers' }
                    }
                }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            assignedJobModel.aggregate(query)
                .exec(function (err, data) {
                    if (err) {
                        reject(err);
                    } else {
                        let tagIds = [];
                        data.forEach(function (dt) {
                            dt.drivers.forEach(function (dr) {
                                tagIds.push(dr.tag_id);
                            });
                        });
                        order == 'asc' ? tagIds.sort() : tagIds.sort().reverse();
                        resolve(tagIds);
                    }
                });
        });
    },
    // assign a tag id to a driver
    _updateDriversConfirmation: function (assignJobId = null, msgId = null, tagId = null) {
        const self = this;
        return new Promise(function (resolve, reject) {
            self.update(
                {
                    '_id': objectId(assignJobId),
                    'drivers.message_id': msgId
                },
                {
                    'drivers.$.tag_id': tagId,
                    'drivers.$.confirmed': true
                },
                false
            )
                .then(function (data) {
                    resolve(data);
                })
                .catch(function (err) {
                    reject(err);
                });
        });
    },
     getAllJobIdUniqueCustomerId: function (conditions = {}, fields = {}, order = {}) {
        return new Promise(function (resolve, reject) {
            var query = [
                {
                    $lookup: {
                        from: 'dispatches',
                        localField: 'dispatch_id',
                        foreignField: '_id',
                        as: 'dispatch'
                    }
                },
                { $unwind: '$dispatch' },
                {
                    $lookup: {
                        from: 'sub_jobs',
                        localField: 'dispatch.job_id',
                        foreignField: '_id',
                        as: 'job'
                    }
                },
                { $unwind: '$job' },
                {
                    $lookup: {
                        from: 'customers',
                       localField: 'job.c_id',
                        foreignField: '_id',
                        as: 'customer'
                    }
                },
                { $unwind: '$customer' },
                {
                    $match: conditions
                },
                {
                    $group: {
                        _id: '$_id',
                        'customer_id': { $first: '$customer.customer_id' },
                        'cust_name': { $first: '$customer.cust_name' },
                        'jobid': { $first: '$job.pjob_id' },
                        'subjobid': { $first: '$job.subjob_id' },
                        'job_name': { $first: '$job.job_name' },
                        'tag_id': { $first: '$drivers.tag_id' },
                        'subjobobjid': { $first: '$job._id' },
                        'c_id': { $first: '$customer._id' },

                        // 'subjobid': { $first: '$job._id' },
                        // 'job_name': { $first: '$job.job_name' },
                        // 'tag_id_status': { $first: '$assign.drivers.tag_id_status' },
                        // 'customer_name': { $first: '$customer.org_name' },
                        // 'jobid': { $first: '$job.pjob_id' },
                        // 'subjobid': { $first: '$job.subjob_id' },
                        // 'customer_id': { $first: '$customer.customer_id' },
                        // 'subjobobjid': { $first: '$job._id' },
                    }
                }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }

            assignedJobModel.aggregate(query)
                .exec(function (err, data) {
                    err ? reject(err) : resolve(data);
                });
        });
    },
}
   