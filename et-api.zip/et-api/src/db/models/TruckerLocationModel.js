const truckerLocationModel = require('../../db/schemas/TruckerLocationSchema').models.truckerLocationModel;
    
module.exports = {

    delete: function (conditions) {
        return new Promise(function (resolve, reject) {
            truckerLocationModel.remove(conditions, function (err) {
                err ? reject(err) : resolve();
            });
        });
    },
    save: function (data) {
        var newTruckerLocation = new truckerLocationModel(data);
        return new Promise(function (resolve, reject) {
            newTruckerLocation.save(function (err, truckerLocation) {
                err ? reject(err) : resolve(truckerLocation);
            });
        });
    },
    getTruckerLocations: function (conditions = {}, fields = {}) {
        return new Promise(function (resolve, reject) {
            var query = truckerLocationModel.find(conditions);
            if (Object.keys(fields).length) {
                query.select(fields);
            }
            query.exec(function (err, truckerLocations) {
                err ? reject(err) : resolve(truckerLocations);
            });
        });
    },
}