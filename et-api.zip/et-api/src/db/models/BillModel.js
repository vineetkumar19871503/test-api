const billModel = require('../../db/schemas/BillSchema').models.quoteModel;

module.exports = {
   
    saveBill: function (data) {
        var newUser = new billModel(data);
        return new Promise(function (resolve, reject) {
            newUser.save(function (err, user) {
                err ? reject(err) : resolve(user);
            });
        });
    }

   
   
}