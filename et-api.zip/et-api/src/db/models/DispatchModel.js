const dispatchModel = require('../../db/schemas/DispatchSchema').models.dispatchModel,
    driverModel = require('../../db/models/DriverModel');
module.exports = {
    getDispatches: function (conditions = {}, fields = {}, order = {}) {
        const self = this;
        return new Promise(function (resolve, reject) {
            var query = [
                {
                    $lookup: {
                        from: 'sub_jobs',
                        localField: 'job_id',
                        foreignField: '_id',
                        as: 'job'
                    }
                },
                { $unwind: '$job' },
                {
                    $match: conditions
                }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }
            dispatchModel.aggregate(query)
                .exec(function (err, dispatches) {
                    err ? reject(err) : resolve(dispatches);
                });
        });
    },
    getDispatchDetails: function (conditions = {}, fields = {}, order = {}) {
        const self = this;
        return new Promise(function (resolve, reject) {
            var query = [
                {
                    $lookup: {
                        from: 'sub_jobs',
                        localField: 'job_id',
                        foreignField: '_id',
                        as: 'job'
                    }
                },
                {
                    $lookup: {
                        from: 'customers',
                        localField: 'job.c_id',
                        foreignField: '_id',
                        as: 'customer'
                    }
                },
                {
                    $lookup: {
                        from: 'assigned_jobs',
                        localField: '_id',
                        foreignField: 'dispatch_id',
                        as: 'assign'
                    }
                },
                {
                    $lookup: {
                        from: 'truckers',
                        localField: 'assign.drivers.driver_id',
                        foreignField: '_id',
                        as: 'drivers'
                    }
                },
                {
                    $lookup: {
                        from: 'subhaulers',
                        localField: 'drivers.subhauler_id',
                        foreignField: '_id',
                        as: 'subhaulers'
                    }
                },
                { $unwind: '$job' },
                { $unwind: '$customer' },
                {
                    $match: conditions
                }
            ];
            if (Object.keys(fields).length) {
                query.push({ $project: fields });
            }
            if (Object.keys(order).length) {
                query.push({ $sort: order });
            }
            dispatchModel.aggregate(query)
                .exec(function (err, dispatches) {
                    self._formatDrivers(dispatches, function (data) {
                        err ? reject(err) : resolve(data);
                    });
                });
        });
    },
    delete: function (conditions) {
        return new Promise(function (resolve, reject) {
            dispatchModel.remove(conditions, function (err) {
                err ? reject(err) : resolve();
            });
        });
    },
    update: function (conditions = {}, data = {}, upsert = true) {
        return new Promise(function (resolve, reject) {
            dispatchModel.update(conditions,
                { $set: data },
                { upsert },
                function (err, res) {
                    err ? reject(err) : resolve(res);
                })
        });
    },
    save: function (data) {
        return new Promise(function (resolve, reject) {
            dispatchModel.insertMany(data, function (err, dispatch) {
                err ? reject(err) : resolve(dispatch);
            });
        });
    },
    // private methods
    _formatDrivers: function (data, cb) {
        if (data.length) {
            cb(data.map(function (dt, i) {
                if (dt.assign.length && dt.assign[0].drivers.length) {
                    var assignDrivers = dt.assign[0].drivers,
                        driversArr = dt.drivers;
                    dt.assign[0].drivers = assignDrivers.map(function (ad, adi) {
                        // merging driver data
                        let _driver;
                        driversArr.filter(function (driver) {
                            if (ad.driver_id && driver._id.toString() === ad.driver_id.toString()) {
                                _driver = Object.assign({}, ad, driver);
                            }
                        });

                        // mergin subhauler data
                        if (_driver && _driver.subhauler_id) {
                            dt.subhaulers.forEach(function (sh) {
                                if (_driver.subhauler_id.toString() == sh._id.toString()) {
                                    _driver.subhauler = sh;
                                }
                            });
                        }
                        return _driver;
                    });
                    dt.assign = dt.assign[0];
                    delete dt.drivers;
                    delete dt.subhaulers;
                } else {
                    dt.assign = {};
                }
                return dt;
            }));
        } else {
            cb(data);
        }
    }
    // getting pullers and drivers for assigned job
    // _getDrivers: function (data, cb) {
    //     if (data.length) {
    //         let counter = 0;
    //         data.forEach(function (dt, ind) {
    //             let drivers = [],
    //                 totalDrivers = dt.drivers.length;
    //             dt.drivers.forEach(function (dr) {
    //                 if (dr.driver_type == 'dr') {
    //                     // get data from drivers collection
    //                     driverModel.getdrivers({ '_id': dr.driver_id })
    //                         .then(function (driver) {
    //                             if (driver.length) {
    //                                 delete driver[0]["'$__'"];
    //                                 drivers.push(Object.assign(dr, driver[0]._doc));
    //                                 if (drivers.length == totalDrivers) {
    //                                     data[ind].drivers = drivers;
    //                                     counter++;
    //                                 }
    //                             }
    //                             if (ind == counter - 1) {
    //                                 cb(data);
    //                             }
    //                         })
    //                 } else if (dr.driver_type == 'pu') {
    //                     // get data from pullers collection
    //                     pullerModel.getPullers({ '_id': dr.driver_id })
    //                         .then(function (puller) {
    //                             if (puller.length) {
    //                                 delete puller[0]["'$__'"];
    //                                 drivers.push(Object.assign(dr, puller[0]._doc));
    //                                 if (drivers.length == totalDrivers) {
    //                                     data[ind].drivers = drivers;
    //                                     counter++;
    //                                 }
    //                             }
    //                             if (ind == counter - 1) {
    //                                 cb(data);
    //                             }
    //                         })
    //                 }
    //             });
    //         });
    //     } else {
    //         cb([]);
    //     }
    // }
}