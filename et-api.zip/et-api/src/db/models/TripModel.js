const tripModel = require('../../db/schemas/TripSchema').models.tripModel;
    
module.exports = {

    delete: function (conditions) {
        return new Promise(function (resolve, reject) {
            tripModel.remove(conditions, function (err) {
                err ? reject(err) : resolve();
            });
        });
    },
    save: function (data) {
        var newTrip = new tripModel(data);
        return new Promise(function (resolve, reject) {
            newTrip.save(function (err, trip) {
                err ? reject(err) : resolve(trip);
            });
        });
    },
    update: function (conditions = {}, data = {}, upsert = true) {
        return new Promise(function (resolve, reject) {
            tripModel.update(conditions,
                { $set: data },
                { upsert },
                function (err, numAffected, raw) {
                    err ? reject(err) : resolve(raw);
                });
        });
    },
    getTrips: function (conditions = {}, fields = {}) {
        return new Promise(function (resolve, reject) {
            var query = tripModel.find(conditions);
            if (Object.keys(fields).length) {
                query.select(fields);
            }
            query.exec(function (err, trips) {
                err ? reject(err) : resolve(trips);
            });
        });
    },
    getDateTrip : function(conditions={},fields={}){
        tripModel.aggregate(
           [
             {
               $project:
                 {
                   year: { $year: fields.created_date },
                   
                 },
                 
             }
           ]
        )
    }
}