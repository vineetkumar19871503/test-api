const truckerSigningOffModel = require('../../db/schemas/TruckerSigningOffSchema').models.truckerSigningOffModel;
    
module.exports = {

    delete: function (conditions) {
        return new Promise(function (resolve, reject) {
            truckerSigningOffModel.remove(conditions, function (err) {
                err ? reject(err) : resolve();
            });
        });
    },
    save: function (data) {
        var newSignOff = new truckerSigningOffModel(data);
        return new Promise(function (resolve, reject) {
            newSignOff.save(function (err, trip) {
                err ? reject(err) : resolve(trip);
            });
        });
    },
    update: function (conditions = {}, data = {}, upsert = true) {
        return new Promise(function (resolve, reject) {
            truckerSigningOffModel.update(conditions,
                { $set: data },
                { upsert },
                function (err, numAffected, raw) {
                    err ? reject(err) : resolve(raw);
                });
        });
    },
    getSignOffDetail: function (conditions = {}, fields = {}) {
        return new Promise(function (resolve, reject) {
            truckerSigningOffModel.findOne(conditions, function (err, signOff) {
                err ? reject(err) : resolve(signOff);
            });
        });
    }
}