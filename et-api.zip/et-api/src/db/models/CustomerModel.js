config = require('../../../config'),
    customerModel = require('../../db/schemas/CustomerSchema').models.customersModel,
    customerLogModel = require('../../db/schemas/CustomerSchema').models.customerLogModel,

    counter = require('../components/counter');
module.exports = {
    getCustomers: function (conditions = {}, fields = {}) {
        return new Promise(function (resolve, reject) {
            var query = customerModel.find(conditions);
            if (Object.keys(fields).length) {
                query.select(fields);
            }
            query.exec(function (err, customers) {
                err ? reject(err) : resolve(customers);
            });
        });
    },
    saveCustomer: function (data) {
        return new Promise(function (resolve, reject) {
            counter.getNextId('customer_id', true, function (error, nextId) {
                if (error) {
                    reject(error);
                } else {
                    data.cust_id = nextId;
                    var newCustomer = new customerModel(data);
                    newCustomer.save(function (err, customer) {
                        err ? reject(err) : resolve(customer);
                    });
                }
            });
        })
    },
    update: function (conditions = {}, data = {}, upsert = true) {
        return new Promise(function (resolve, reject) {
            const custLogs = Object.assign({}, data.cust_logs);
            delete data.cust_logs;
            customerModel.update(conditions,
                {
                    $set: data,
                    $push: { 'cust_logs': custLogs }
                },
                { upsert },
                function (err, res) {
                    err ? reject(err) : resolve(res);
                })
        });
    },
    saveCustomer_logs: function (data) {
        var newcust_log = new customerlogModel(data);
        return new Promise(function (resolve, reject) {
            newcust_log.save(function (err, cust_log) {
                err ? reject(err) : resolve(cust_log);
            });
        });
    },
} 