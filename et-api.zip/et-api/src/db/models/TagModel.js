const tagModel = require('../../db/schemas/TagSchema').models.tagModel;
module.exports = {
    save: function (data) {
        console.log('AAAaaaa',data);
        return new Promise(function (resolve, reject) {
            tagModel.insertMany(data, function (err, quote) {
                err ? reject(err) : resolve(quote);
            });
        });
    },
}

