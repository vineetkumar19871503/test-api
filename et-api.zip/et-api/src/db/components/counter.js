const mongoose = require('mongoose'),
    Schema = mongoose.Schema;
const counterSchema = new Schema({
    _id: String,
    seq: Number
});

const counterModel = mongoose.model('counters', counterSchema);
module.exports = {
    resetCounter: function (name, cb) {
        const self = this;
        counterModel.findOneAndUpdate({ _id: name }, { $set: { seq: 0 } }, { new: true }, function (err, doc) {
            cb(err);
        });
    },
    getNextId: function (name, addZeroes, cb) {
        const self = this;
        counterModel.findOneAndUpdate({ _id: name }, { $inc: { seq: 1 } }, { new: true }, function (err, doc) {
            let nextId = doc.seq;
            if (addZeroes) {
                nextId = self.addZeroes(name, nextId);
            }
            cb(err, nextId);
        });
    },
    addZeroes: function (name, id) {
        // specify which id contains how many digits (eg. 0001 for job)
        const idLength = {
            'tag_id': 4,
            'customer_id': 4,
            'job_id': 4,
            'subjob_id': 3
        };
        const length = idLength[name] ? idLength[name] : 4;
        const zeroesToAdd = length - id.toString().length;
        return '0'.repeat(zeroesToAdd) + id;
    }
}
