const authHandler = require('../handlers/AuthHandler'),
    tagModel = require('../db/models/TagModel'),
    ObjectId = require('mongoose').Types.ObjectId;
module.exports = {
    name: 'tags',
    get: {
        
    },
    post: {
        add: function (req, res, next) {
            authHandler(req, res, next, function () {
                tagModel.save(req.body)
                    .then(function (data) {
                        res.rest.success({
                            'data': data,
                            'message': 'Tag saved successfully!'
                        });
                    })
                    .catch(function (err) {
                        res.rest.serverError({
                            'message': 'Error : tag could not be saved! ' + err.message
                        });
                    });
            });
        }
        
    }
}