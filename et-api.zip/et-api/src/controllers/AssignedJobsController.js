const authHandler = require('../handlers/AuthHandler'),
    assignedJobModel = require('../db/models/AssignedJobModel'),
    driverModel = require('../db/models/DriverModel'),
    objectId = require('mongoose').Types.ObjectId;
module.exports = {
    name: 'assigned_jobs',
    get: {
        index: function (req, res, next) {
            authHandler(req, res, next, function () {
                assignedJobModel.getAssignedJobs(conditions)
                    .then(function (jobs) {
                        var response = {
                            message: 'Assigned Jobs not found!'
                        };
                        if (jobs.length) {
                            response.message = 'Assigned Jobs';
                        }
                        response.data = jobs;
                        res.rest.success(response);
                    })
                    .catch(function (err) {
                        res.rest.serverError({
                            error: err.message
                        });
                    });
            });
        },
        getAssignDetailByJobId(req, res, next) {
            let conditions = {};
            if (typeof req.query.job_id != 'undefined') {
                conditions = { 'job_id': objectId(req.query.job_id) };
            }
            assignedJobModel.getAssignedJobs(conditions, {}, { 'time': 1 })
                .then(function (jobs) {
                    var response = {
                        message: 'No record found!'
                    };
                    if (jobs.length) {
                        response.message = 'Assigned Job';
                    }
                    response.data = jobs;
                    res.rest.success(response);
                })
                .catch(function (err) {
                    res.rest.serverError(err.message);
                });
        },
        getAllTagidGeneratedSubJob(req, res, next) {
            var conditions = {};
            if (typeof req.query.date != 'undefined') {
                const dt = new Date(req.query.date),
                    nextDate = new Date(req.query.date);
                nextDate.setDate(dt.getDate() + 1);
                dt.setHours(0, 0, 0, 0);
                nextDate.setHours(0, 0, 0, 0);
                dt.toISOString();
                nextDate.toISOString();
                conditions['start_time'] = {
                    '$gte': dt,
                    '$lt': nextDate
                };
            }
            assignedJobModel.getAllTagidGeneratedSubJob(conditions)
                .then(function (jobs) {
                    var newData = [];
                    jobs.forEach(function (data, index) {
                        function checkTagId(job) {
                            return job;
                        }
                        var checkNullTagId = data.tag_id.filter(checkTagId)
                        if (checkNullTagId.length > 0) {
                            newData.push(data);
                        }
                    });
                    var response = {
                        message: 'No record found!'
                    };
                    if (newData.length) {
                        response.message = 'Assigned Job';
                    }
                    response.data = newData;
                    res.rest.success(response);
                })
                .catch(function (err) {
                    res.rest.serverError(err.message);
                });
        },
        getTagidGeneratedBySingleSubJob(req, res, next) {
            var conditions = {};

            conditions = { 'job_id': objectId(req.query.JobId) };
            //  ,'drivers.tag_id_status' : { $ne: 'finished' }
            // conditions = {
            //     'drivers.tag_id': {
            //         $ne: null
            //     }
            // }
            if (typeof req.query.datevalue != 'undefined') {
                const dt = new Date(req.query.datevalue),
                    nextDate = new Date(req.query.datevalue);
                nextDate.setDate(dt.getDate() + 1);
                dt.setHours(0, 0, 0, 0);
                nextDate.setHours(0, 0, 0, 0);
                dt.toISOString();
                nextDate.toISOString();
                conditions['start_time'] = {
                    '$gte': dt,
                    '$lt': nextDate
                };
            }
            assignedJobModel.getTagidGeneratedBySingleSubJob(conditions)
                .then(function (jobs) {
                    var newData = [],
                        response = { message: 'No record found!', data: [] };
                    jobs[0].tag_id.forEach(function (data, index) {
                        if (data) {
                            newData.push({
                                "tag_id": data, "jobsite": jobs[0].jobsite,
                                "querysite": jobs[0].querysite,
                                "tag_id_status": jobs[0].tag_id_status[index],
                                "customer_name": jobs[0].customer_name,
                                "customer_id": jobs[0].customer_id,
                                "jobid": jobs[0].jobid,
                                "subjobid": jobs[0].subjobid,
                                "c_id": jobs[0].c_id
                            });
                        }
                    });
                    if (newData.length) {
                        response.message = 'Assigned Job';
                    }
                    response.data = newData;
                    res.rest.success(response);
                })
                .catch(function (err) {
                    res.rest.serverError(err.message);
                });
        },
        getAllJobIdUniqueCustomerId(req, res, next) {
            var conditions = { 'customer._id': objectId(req.query.c_id) };
            if (typeof req.query.datevalue != 'undefined') {
                const dt = new Date(req.query.datevalue),
                    nextDate = new Date(req.query.datevalue);
                nextDate.setDate(dt.getDate() + 1);
                dt.setHours(0, 0, 0, 0);
                nextDate.setHours(0, 0, 0, 0);
                dt.toISOString();
                nextDate.toISOString();
                conditions['start_time'] = {
                    '$gte': dt,
                    '$lt': nextDate
                };
            }

            assignedJobModel.getAllJobIdUniqueCustomerId(conditions)
                .then(function (jobs) {

                    var newData = [];
                    jobs.forEach(function (data, index) {

                        function checkTagId(job) {
                            return job;
                        }
                        var checkNullTagId = data.tag_id.filter(checkTagId)
                        if (checkNullTagId.length > 0) {
                            newData.push(data);
                        }
                    });
                    var response = {
                        message: 'No record found!'
                    };
                    if (newData.length) {
                        response.message = 'Assigned Job';
                    }
                    response.data = newData;
                    res.rest.success(response);
                })
                .catch(function (err) {
                    res.rest.serverError(err.message);
                });
        },
        // approve the driver's job based on message id
        approveDriversJob: function (req, res, next) {
            if (req.query.msg_id) {
                const conditions = { 'drivers.message_id': req.query.msg_id },
                    now = new Date();
                now.setHours(now.getHours() - 2);
                assignedJobModel.approveDriversJob(
                    {
                        'drivers.message_id': req.query.msg_id,
                        'drivers.cancelled': false,
                        'drivers.confirmed': false,
                        'drivers.assigned_time': { $gt: now }
                    },
                    {
                        'dispatch.date': 1,
                        'driver.driver_id': 1,
                        'customer.customer_id': 1,
                        'job.customer_id': 1,
                        'job.pjob_id': 1,
                        'job.subjob_id': 1
                    }
                )
                    .then(function (data) {
                        res.rest.success({
                            'message': 'Job has been approved successfully!'
                        });
                    })
                    .catch(function (err) {
                        res.rest.serverError({
                            'message': 'Error : Job could not be approved! ' + err.message
                        });
                    });

            } else {
                res.rest.serverError({
                    'message': 'Invalid request. Please provide message id!'
                });
            }
        },
        getAllDataByTagId: function (req, res, next) {
            let conditions = {};
            if (typeof req.query.id != 'undefined') {
                conditions = { 'drivers.tag_id': req.query.id };
            }
            assignedJobModel.getTruckersByTagidNew(conditions)
                .then(function (jobs) {
                    var response = {
                        message: 'No record found!'
                    };
                    if (jobs.length) {
                        response.message = 'Assigned Job';
                    }
                    if (jobs.length) {
                        const j = jobs[0];
                        j.driver_detail = j.driver_detail.filter(function (dr) {
                            if (dr._id.toString() === j.driver.driver_id.toString()) {
                                return dr;
                            }
                        });
                    }
                    response.data = jobs;
                    res.rest.success(response);
                })
                .catch(function (err) {
                    res.rest.serverError(err.message);
                });
        }

    },
    post: {
        add: function (req, res, next) {
            authHandler(req, res, next, function () {
                // get assign job detail by dispatch id so that we can merge the drivers to the existing ones to get rid of losing previous driver details (eg: tag_id, confirmed etc.)
                assignedJobModel.getAssignedDataByDispatchId(req.body.dispatch_id)
                    .then(function (assignedJob) {
                        // merging db drivers with new drivers
                        if (assignedJob.length && assignedJob[0].drivers.length) {
                            const drivers = assignedJob[0].drivers;
                            req.body.drivers = req.body.drivers.map(function (reqDr) {
                                let _dr = reqDr;
                                drivers.forEach(function (eDr) {
                                    eDr = JSON.parse(JSON.stringify(eDr));
                                    if (eDr.driver_id == reqDr.driver_id) {
                                        _dr = Object.assign({}, eDr, reqDr);
                                    }
                                });
                                return _dr;
                            });
                        }
                        // merging posted drivers with the existing ones
                        assignedJobModel.update({ 'dispatch_id': req.body.dispatch_id }, req.body)
                            .then(function (response) {
                                if (req.body.drivers.length) {
                                    const driverIds = req.body.drivers.map(function (dr) {
                                        return objectId(dr.driver_id);
                                    });
                                    // update the drivers is_assigned status
                                    driverModel.update({ '_id': { $in: driverIds } }, { 'is_assigned': true, 'assigned_time': new Date() }, false, true);
                                }
                                // let driverToNotify = [];
                                // if (req.body.drivers.length) {
                                //     req.body.drivers.map(function (dr) {
                                //         if (!dr.conf_sent) {
                                //             driverToNotify.push(dr.phone);
                                //         }
                                //     })
                                // }
                                // // send sms
                                // console.log(driverToNotify);
                                res.rest.success({
                                    'message': 'Job is assigned successfully!'
                                });
                            })
                            .catch(function (err) {
                                res.rest.serverError({
                                    'message': err + 'Error : Job could not be assigned!'
                                });
                            });
                    });

            });
        },
        cancelDriver: function (req, res, next) {
            authHandler(req, res, next, function () {
                let conditions = {};
                if (req.body.dispatch_id && req.body.driver_id) {
                    conditions = { 'dispatch_id': req.body.dispatch_id };
                    assignedJobModel.getAssignedDataByDispatchId(objectId(req.body.dispatch_id))
                        .then(function (dt) {
                            const drivers = dt[0].drivers.map(function (drv) {
                                if (drv.driver_id.toString() == req.body.driver_id) {
                                    drv.confirmed = false;
                                    drv.cancelled = true;
                                    drv.driver_status = null;
                                }
                                return drv;
                            });
                            assignedJobModel.update(conditions, { 'drivers': drivers })
                                .then(function (response) {

                                    // release the driver (set is_assigned flag to false)
                                    driverModel.update({ '_id': objectId(req.body.driver_id) }, { 'is_assigned': false, 'job_approved': false }, false, false);

                                    res.rest.success({
                                        'message': 'Driver cancelled successfully!'
                                    });
                                })
                                .catch(function (err) {
                                    res.rest.serverError({
                                        'message': err + 'Error : Driver could not be cancelled!'
                                    });
                                });
                        });

                } else {
                    res.rest.serverError({
                        'message': 'Invalid request! Please provide both dispatch id and driver id.'
                    });
                }
            });
        }
    }
}